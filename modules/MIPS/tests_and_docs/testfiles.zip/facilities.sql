INSERT INTO `facility` (`id`, `name`, `street`, `city`, `state`, `postal_code`, `country_code`, `federal_ein`, `service_location`, `billing_location`, `accepts_assignment`, `pos_code`, `attn`, `facility_npi`, `tax_id_type`, `color`, `primary_business_entity`) VALUES
('1','Beringer','1659 66TH STREET ','BROOKLYN','NY','112041824','USA','112652666','1','0','1','11','Billing','1871514372','EI','#FFCC99','0'),
('2','Ned I Beringer PC','1659 66TH STREET ','BROOKLYN','NY','112041824','USA','112652666','1','0','1','11','Billing','1942504543','EI','#FFCC99','0'),
('3','MAIMONIDES MEDICAL CENTER','4802 TENTH AVENUE ','BROOKLYN','NY','112192916','USA','','1','0','1','21','Billing','1093777492','EI','#FFCC99','0'),
('4','BORO PARK CNTR NURSING  REHAB','4915 10TH AVENUE ','BROOKLYN','NY','112193301','USA','','1','0','1','32','Billing','1982913109','EI','#FFCC99','0'),
('5','MAIMONIDES MEDICAL CENTER','4802 TENTH AVENUE ','BROOKLYN','NY','112192916','USA','','1','0','1','11','Billing','1093777492','EI','#FFCC99','0'),
('6','NED I Beringer PC2','1659 66TH STREET ','BROOKLYN','NY','112041824','USA','112652666','1','0','1','12','Billing','1942504543','EI','#FFCC99','0');